## 🌘Hikka Userbot Modules

This repository contains a collection of modules for the Hikka Userbot. To install a module, simply copy the raw file link.

### 👤About Me

You can contact me on Telegram. Feel free to reach out with any questions or inquiries.

### 💾How install

You can install my modules using raw links. For example:
```
.dlm https://raw.githubusercontent.com/N3rcy/modules/main/{module name}
```
And you can use my repository, just add my repo:
```
.addrepo https://raw.githubusercontent.com/N3rcy/modules/main
```
After this you will can install mod simple:
```
.dlm {module name}
```
